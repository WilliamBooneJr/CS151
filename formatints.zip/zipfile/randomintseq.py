#Billy Boone
#09/22/2023
#This program takes two command line arguments, number range and the count for that number range.
#It then writes the sequence of random integers to standard output.
import stdio 
import sys
import random

number_range = int(sys.argv[1]) #get the number range
number_count = int(sys.argv[2]) #get the count for number range


for i in range(number_count): #output
    number = random.randint(0, number_range)
    stdio.writeln(number)
