#Billy Boone
#09/22/2023
#This program processes standard output and formats/filters integers to 10 per line.
import stdio

numbers_to_output = [] #container to hold numbers 

while not stdio.isEmpty(): #Run while there is still input
    value = stdio.readInt()
    numbers_to_output.append(value) #Add values from input to container

for i in range(len(numbers_to_output)): #output the numbers
    if i % 10 == 0: #if the iteration is divisible by 10, start a new line
        stdio.writeln()
    stdio.writef('%-5d', numbers_to_output[i]) #format the output to 5 spaces trailing.